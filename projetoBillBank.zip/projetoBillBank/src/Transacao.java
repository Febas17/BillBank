public class Transacao {
    String tipoTransacao, data, contaOrigem, contaDestino;
    int valor;

    void exibirDetalhes(){ //falta fazer
    }
}
