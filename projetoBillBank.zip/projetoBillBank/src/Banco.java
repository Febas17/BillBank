public class Banco {
    
    void cadastrarCliente(){

    }
    void executarTransacao(){

    }
    
    void emitirRelatorio(){

    }
}