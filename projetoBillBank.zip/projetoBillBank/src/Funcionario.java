public class Funcionario {
    String nome, cargo, permissoes;
    void aprovarTransacao(){
    }

    void gerarRelatorio(){
    }
}
